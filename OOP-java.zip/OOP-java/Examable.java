package project_Dvir_Siksik_Rotem_Ler;

import java.io.FileNotFoundException;

public interface  Examable  {
	void creatExam(Stock theStock) throws FileNotFoundException, Exception;
	
}

