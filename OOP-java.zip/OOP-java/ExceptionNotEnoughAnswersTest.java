package project_Dvir_Siksik_Rotem_Ler;

public class ExceptionNotEnoughAnswersTest extends Exception{
	public ExceptionNotEnoughAnswersTest(String msg) {
		super(msg);
	}

}
