package project_Dvir_Siksik_Rotem_Ler;

public class ExceptionMaxNumQuestions extends Exception{
	public ExceptionMaxNumQuestions(String msg) {
		super(msg);
	}
}
